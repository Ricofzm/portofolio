# Enriko Fazar Maulana — Portfolio

Personal portfolio site, redesigned with a "control panel" glassmorphism theme —
glass panels, panel/log numbering, and an animated instrument-style gauge — inspired
by the gas distribution & instrumentation work described in the content itself.

## Live structure

```
.
├── index.html            # markup only
├── css/
│   └── style.css         # design system (tokens, layout, components, responsive)
├── js/
│   └── main.js           # loader, typed text, scroll reveal, progress bar, active nav
├── assets/
│   └── img/
│       ├── profile/          # profile photo
│       ├── experience/        # work experience gallery
│       └── organization/      # organization experience gallery
└── README.md
```

Previously all CSS and JS lived inline inside `index.html` (1100+ lines) and images sat
loose in the repo root with inconsistent naming/casing (`kerja1.JPG`, `organisasi1.jpg`).
Everything is now split by responsibility and images are grouped by section with
consistent lowercase, hyphenated names — easier to navigate, edit, and deploy
(e.g. GitHub Pages, Netlify, Vercel).

## Editing content

- **Text/sections** → `index.html`
- **Colors/type/spacing/animations** → `css/style.css` (see the `:root` tokens at the top)
- **Behavior** (typed strings, scroll reveal targets) → `js/main.js`
- **Images** → replace files in `assets/img/...` keeping the same filenames, or update
  the `src` paths in `index.html`

## Tech

Static HTML/CSS/JS. External libraries via CDN: [Boxicons](https://boxicons.com/),
[ScrollReveal](https://scrollrevealjs.org/), [Typed.js](https://mattboldt.com/demos/typed-js/),
Google Fonts (Space Grotesk, Inter, JetBrains Mono).
